# Maria Eduarda - Next.js

Projeto simples em Next.js com App Router e JavaScript, pronto para publicar na Vercel.

## Rodar localmente

```bash
npm install
npm run dev
```

Depois abra `http://localhost:3000`.

## Onde alterar

- Textos: `app/page.js`
- Cores e estilos: `app/globals.css`
