import "./globals.css";

export const metadata = {
  title: "Analisador de Texto",
  description: "Projeto simples em Next.js pronto para publicar na Vercel.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
