"use client";

import { useState } from "react";

// Textos principais: altere aqui quando quiser.
const TITULO = "Analisador de Texto";
const SUBTITULO = "Digite um texto abaixo e clique em Analisar.";
const TEXTO_BOTAO = "Analisar";

export default function Home() {
  const [texto, setTexto] = useState("");
  const [resposta, setResposta] = useState("");

  function analisar() {
    setResposta(texto);
  }

  return (
    <main className="pagina">
      <section className="cartao">
        <h1>{TITULO}</h1>
        <p className="subtitulo">{SUBTITULO}</p>

        <textarea
          className="campoTexto"
          placeholder="Digite seu texto aqui..."
          value={texto}
          onChange={(event) => setTexto(event.target.value)}
        />

        <button className="botao" onClick={analisar}>
          {TEXTO_BOTAO}
        </button>

        <div className="resposta" aria-live="polite">
          {resposta}
        </div>
      </section>
    </main>
  );
}
